package com.example.demo.dto;

public class SchemeSelectionDto {
    private String schemeChoice;
    private String lifeCycleFund;
    
    // Getters and Setters
    public String getSchemeChoice() { return schemeChoice; }
    public void setSchemeChoice(String schemeChoice) { this.schemeChoice = schemeChoice; }
    
    public String getLifeCycleFund() { return lifeCycleFund; }
    public void setLifeCycleFund(String lifeCycleFund) { this.lifeCycleFund = lifeCycleFund; }
}