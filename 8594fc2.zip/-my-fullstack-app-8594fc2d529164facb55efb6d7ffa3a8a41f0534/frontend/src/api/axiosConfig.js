import axios from 'axios';

const api = axios.create({
    baseURL: '/api',  // Changed: Relative path—proxied by nginx to backend
});

// Interceptor to add JWT to every request
api.interceptors.request.use(config => {
    const token = localStorage.getItem('authToken');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, error => {
    return Promise.reject(error);
});

export default api;